let readline = require("readline");

let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let employees = [];

function getEMP() {
    return new Promise((resolve) => {
        rl.question("write id: ", (id)=>{
            id=Number(id.trim());
            
            rl.question("write name: ", (name)=>{
                name = name.toLowerCase().trim();

                rl.question("write salary: ", (salary) =>{
                    salary= Number(salary.trim());

                    let newEmp={
                        id : id,
                        name : name,
                        salary : salary
                    }

                    employees= [...employees, newEmp];
                    resolve(employees);
                });
            });
        });
    });
}

function close(){
    rl.close();
}

module.exports = {
    getEMP,
    close
};
