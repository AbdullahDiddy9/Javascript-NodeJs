let readline = require("readline");

let rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function question (text){
    return new Promise ((resolve)=>{
        rl.question(text , resolve);
    });
}

let employees = [];

async function getEMP() {
    let count = await question("How many employees: ");
    count = Number(count);

    for (let i = 0 ; i < count ; i++){
        let id = await question("Enter ID: ");
        let name = await question("Enter Name: ");
        let salary = await question("Enter Salary: ");

        let newEmp = {
            id : Number(id),
            name : name.toLowerCase().trim(),
            salary : Number(salary)
        };

        employees = [...employees, newEmp];
    }
    return employees;

}

function close(){
    rl.close();
}

module.exports = {
    getEMP,
    close
};
