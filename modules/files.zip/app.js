const student = require ("./student");

async function main(){
    const name = await student.getName();
    const marks = await student.getMarks();

    console.log("Name: ", name);
    console.log("Marks: ", marks);

    student.close();
}
main();
