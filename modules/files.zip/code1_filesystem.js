let fs = require ("fs");
fs.writeFile("data.txt" , "hello" , (err) => {
    if (err){
        console.log(err);
    }
    else 
        console.log("data written");
});

fs.appendFile("data.txt" , "HELLO" , (err) =>{
    if (err){
        console.log(err);
    }
    else
        console.log("data appended");
});
