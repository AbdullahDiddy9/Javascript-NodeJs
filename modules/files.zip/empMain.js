const emp = require("./Employee");

async function main() {
    const employee = await emp.getEMP();

    console.log(employee);

    emp.close();
}

main();
