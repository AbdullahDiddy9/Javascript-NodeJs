const emp = require("./EmployeeMulti");

async function main() {

    const employees = await emp.getEMP();

    console.log(employees);

    emp.close();
}

main();
