README (Batch 4)
=================

This folder contains four tasks, independent from the previous batches.
Topics covered: the File System module, and the module export/import
pattern (module.exports / require) combined with Promises and async/await.

NOTE: In the original code files 2, 3, and 4 all used the same filenames
(student.js/app.js style collisions). To keep each task runnable without
overwriting another, the module and main files have been renamed per task
as listed below. The code logic itself is unchanged except for Code 4,
where a few bugs were fixed (explained below).

----------------------------------------
1) code1_filesystem.js
----------------------------------------
What it does:
- Uses the built-in "fs" module.
- fs.writeFile() creates/overwrites "data.txt" with the text "hello".
- fs.appendFile() then appends the text "HELLO" to the same file.
- Logs a success message for each operation, or the error if one occurs.

Run with:
    node code1_filesystem.js

Note: Because writeFile and appendFile both run asynchronously and are
not chained, appendFile may sometimes run before writeFile finishes. For
guaranteed order, appendFile should be called inside writeFile's callback.

----------------------------------------
2) student.js + app.js
----------------------------------------
What it does:
- student.js is a module exporting three functions:
    getName()  -> returns a Promise that resolves with the typed name
    getMarks() -> returns a Promise that resolves with the typed marks
    close()    -> closes the readline interface
- app.js imports this module with require("./student"), then uses
  async/await to get the name and marks, prints them, and closes readline.

Run with (from the folder containing both files):
    node app.js

----------------------------------------
3) Employee.js + empMain.js
----------------------------------------
What it does:
- Employee.js is a module exporting:
    getEMP() -> asks for id, name, and salary (one employee), returns a
                Promise that resolves with the employees array
    close()  -> closes the readline interface
- empMain.js imports this module with require("./Employee"), awaits
  getEMP(), logs the resulting array, and closes readline.

Run with (from the folder containing both files):
    node empMain.js

----------------------------------------
4) EmployeeMulti.js + empMultiMain.js (bugs fixed)
----------------------------------------
What it does:
- EmployeeMulti.js is a module that asks how many employees to enter,
  then loops that many times asking for ID, Name, and Salary for each
  one, building up an "employees" array using the spread operator.
- Exports getEMP() (returns the full employees array) and close().
- empMultiMain.js imports this module with require("./EmployeeMulti"),
  awaits getEMP(), logs the array, and closes readline.

Bugs fixed from the original code:
  1. "let count = question(...)" was missing "await", so count was a
     Promise instead of the actual answer. Fixed to:
         let count = await question("How many employees: ");
  2. "number(count)" is not a valid JS function. Fixed to:
         count = Number(count);
  3. The for-loop condition "i < count < i++" was invalid syntax/logic.
     Fixed to:
         for (let i = 0; i < count; i++)
  4. "return employess;" had a typo. Fixed to:
         return employees;

Run with (from the folder containing both files):
    node empMultiMain.js

----------------------------------------
General Requirements
----------------------------------------
- Node.js must be installed on your computer.
- Each module + main file pair must be kept in the SAME folder together,
  since the main file uses require("./filename") to import the module.
- Run the "main" file (app.js, empMain.js, empMultiMain.js) — not the
  module file — since the module files only export functions and do not
  run on their own.
- All scripts that use readline are interactive and will prompt you for
  input in the terminal.
