let readline = require("readline");

let rl = readline.createInterface({

    input: process.stdin,

    output: process.stdout

});

function getName() {

    return new Promise((resolve) => {

        rl.question("Write name: ", (name) => {

            resolve(name.toLowerCase().trim());

        });

    });

}

function getMarks() {

    return new Promise((resolve) => {

        rl.question("Write marks: ", (num) => {

            num = Number(num.trim());

            resolve(num);

        });

    });

}

function close() {

    rl.close();

}

module.exports = {

    getName,

    getMarks,

    close

};
